package com.example.aquib.viewpagerusingfragmentslayout;

import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.aquib.viewpagerusingfragmentslayout.adapter.CoustmisedPagerAdapter;

import me.relex.circleindicator.CircleIndicator;

public class MainActivity extends FragmentActivity {

    CircleIndicator mCircleIndicator;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mCircleIndicator = (CircleIndicator) findViewById(R.id.circle_indicator);
        ViewPager mViewPager = (ViewPager) findViewById(R.id.vp_pager);

        //Setting view pager to adapter
        //we don't have to pass anything to its adapter in this case;but if we need to pass,
        //we gonna pass like 'mViewPager.setAdapter(new CoustmisedPagerAdapter(getSupportFragmentManager(),arg1,arg2));'
        mViewPager.setAdapter(new CoustmisedPagerAdapter(getSupportFragmentManager()));

        if (mCircleIndicator != null) {
            mCircleIndicator.setViewPager(mViewPager);
        }

        //Enabling viewpager OnPageChangeListener its Automatically called when we change viewpager screen
        //and here we will get the different screens and all changes (if needed) be done here.
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                switch (position)
                {
                    case 0:
                    {
                        mCircleIndicator.setVisibility(View.VISIBLE);
                        break;
                    }
                    case 1:
                    {
                        mCircleIndicator.setVisibility(View.VISIBLE);
                        break;

                    }
                    case 2:
                    {
                        mCircleIndicator.setVisibility(View.VISIBLE);
                        break;

                    }
                    case 3:
                    {
                        mCircleIndicator.setVisibility(View.INVISIBLE);
                        break;

                    }
                }

            }

            @Override
            public void onPageSelected(int position) {

            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }
}
