package com.example.aquib.viewpagerusingfragmentslayout.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import com.example.aquib.viewpagerusingfragmentslayout.Fragment.TutorialScreen1;
import com.example.aquib.viewpagerusingfragmentslayout.Fragment.TutorialScreen2;
import com.example.aquib.viewpagerusingfragmentslayout.Fragment.TutorialScreen3;
import com.example.aquib.viewpagerusingfragmentslayout.Fragment.TutorialScreen4;

/**
 * Created by AQUIB on 14/7/16.
 *
 */
public class CoustmisedPagerAdapter extends FragmentPagerAdapter {

    //FragmentPaqerAdapter has no default constructor;
    //but it has a single Argumented Constructor.as follows.
    //if we gotta get anything passed from its class.
    //we gonna get it like'public CoustmisedPagerAdapter(FragmentManager fm,type arg1,type arg2){...}'
    public CoustmisedPagerAdapter(FragmentManager fm)
    {
        super(fm);

    }

    //here we gonna pass number of fragments we made
    @Override
    public int getCount() {
        return 4;
    }

    //this will fetch all our screens,but it doesn't inflate all time;
    //if we need to make any chnges on any fragmnet we can't do it here.we have to do it in
    //viewpager.addOnPageChangeListener in its class.
    @Override
    public Fragment getItem(int position) {

        switch(position) {

            case 0:return TutorialScreen1.newInstance("FirstFragment, Instance 1");
            case 1:return TutorialScreen2.newInstance("SecondFragment, Instance 1");
            case 2:return TutorialScreen3.newInstance("ThirdFragment, Instance 1");
            case 3:return TutorialScreen4.newInstance("FourthFragment, Instance 1");
            default:return TutorialScreen1.newInstance("FirstFragment, Default");

        }
    }
}
