package com.example.aquib.viewpagerusingfragmentslayout.Fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.example.aquib.viewpagerusingfragmentslayout.R;

/**
 * Created by AQUIB on 18/7/16.
 *
 */
public class TutorialScreen1  extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.tutorial_screen_1, container, false);
    }

    public static TutorialScreen1 newInstance(String text) {

        TutorialScreen1 f = new TutorialScreen1();
        Bundle b = new Bundle();
        b.putString("msg", text);

        f.setArguments(b);

        return f;
    }
}
